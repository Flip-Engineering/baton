/* This file was automatically generated.  Do not edit! */
void fossil_fatal(const char *zFormat,...);
enum eTktShowEnc { tktNoTab=0, tktFossilize=1 };
typedef enum eTktShowEnc eTktShowEnc;
typedef enum eTktShowEnc tTktShowEncoding;
void rptshow(const char *zRep,const char *zSepIn,const char *zFilter,tTktShowEncoding enc);
int output_separated_file(void *pUser,int nArg,char **azArg,char **azName);
char *fossilize(const char *zIn,int nIn);
#define INTERFACE 0
void fossil_print(const char *zFormat,...);
void rpt_list_reports(void);
void cgi_set_content_type(const char *zType);
struct tm *fossil_localtime(const time_t *clock);
#define count(X)  (sizeof(X)/sizeof(X[0]))
void rptview_page(void);
void fossil_free(void *p);
void *fossil_malloc(size_t n);
int sqlite3_exec_readonly(sqlite3 *db,const char *zSql,sqlite3_callback xCallback,void *pArg,char **pzErrMsg);
typedef struct Blob Blob;
void wiki_convert(Blob *pIn,Blob *pOut,int flags);
void blob_init(Blob *pBlob,const char *zData,int size);
void style_submenu_element(const char *zLabel,const char *zTitle,const char *zLink,...);
typedef struct Stmt Stmt;
int db_finalize(Stmt *pStmt);
char *db_column_malloc(Stmt *pStmt,int N);
const char *ticket_key_template(void);
char *ticket_report_template(void);
i64 db_last_insert_rowid(void);
int db_exists(const char *zSql,...);
void login_insert_csrf_secret(void);
char *db_text(char *zDefault,const char *zSql,...);
void cgi_redirect(const char *zURL);
int db_multi_exec(const char *zSql,...);
void login_verify_csrf_secret(void);
const char *cgi_parameter(const char *zName,const char *zDefault);
#define P(x)        cgi_parameter((x),0)
void view_edit(void);
void output_color_key(const char *zClrKey,int horiz,char *zTabArgs);
void cgi_printf(const char *zFormat,...);
#define PD(x,y)     cgi_parameter((x),(y))
void view_see_sql(void);
int fossil_strnicmp(const char *zA,const char *zB,int nByte);
char *verify_sql_statement(char *zSql);
int fossil_stricmp(const char *zA,const char *zB);
int report_query_authorizer(void *pError,int code,const char *zArg1,const char *zArg2,const char *zArg3,const char *zArg4);
char *remove_blank_lines(const char *zOrig);
int fossil_isdigit(char c);
char *extract_integer(const char *zOrig);
char *mprintf(const char *zFormat,...);
int fossil_isspace(char c);
char *trim_string(const char *zOrig);
void style_footer(void);
void blob_reset(Blob *pBlob);
int Th_Render(const char *z);
char *blob_str(Blob *p);
void Th_Store(const char *zName,const char *zValue);
int fossil_strcmp(const char *zA,const char *zB);
void blob_appendf(Blob *pBlob,const char *zFormat,...);
int db_column_int(Stmt *pStmt,int N);
const char *db_column_text(Stmt *pStmt,int N);
int db_step(Stmt *pStmt);
int db_prepare(Stmt *pStmt,const char *zFormat,...);
void ticket_init(void);
void blob_zero(Blob *pBlob);
const char *ticket_reportlist_code(void);
void Th_Trace(const char *zFormat,...);
void style_header(const char *zTitleFormat,...);
void login_needed(void);
typedef struct Global Global;
struct Blob {
  unsigned int nUsed;            /* Number of bytes used in aData[] */
  unsigned int nAlloc;           /* Number of bytes allocated for aData[] */
  unsigned int iCursor;          /* Next character of input to parse */
  char *aData;                   /* Where the information is stored */
  void (*xRealloc)(Blob*, unsigned int); /* Function to reallocate the buffer */
};
typedef struct Th_Interp Th_Interp;
#define MX_AUX  5
struct Global {
  int argc; char **argv;  /* Command-line arguments to the program */
  int isConst;            /* True if the output is unchanging */
  sqlite3 *db;            /* The connection to the databases */
  sqlite3 *dbConfig;      /* Separate connection for global_config table */
  int useAttach;          /* True if global_config is attached to repository */
  int configOpen;         /* True if the config database is open */
  sqlite3_int64 now;      /* Seconds since 1970 */
  int repositoryOpen;     /* True if the main repository database is open */
  char *zRepositoryName;  /* Name of the repository database */
  const char *zMainDbType;/* "configdb", "localdb", or "repository" */
  const char *zHome;      /* Name of user home directory */
  int localOpen;          /* True if the local database is open */
  char *zLocalRoot;       /* The directory holding the  local database */
  int minPrefix;          /* Number of digits needed for a distinct UUID */
  int fSqlTrace;          /* True if --sqltrace flag is present */
  int fSqlStats;          /* True if --sqltrace or --sqlstats are present */
  int fSqlPrint;          /* True if -sqlprint flag is present */
  int fQuiet;             /* True if -quiet flag is present */
  int fHttpTrace;         /* Trace outbound HTTP requests */
  int fSystemTrace;       /* Trace calls to fossil_system(), --systemtrace */
  int fNoSync;            /* Do not do an autosync even.  --nosync */
  char *zPath;            /* Name of webpage being served */
  char *zExtra;           /* Extra path information past the webpage name */
  char *zBaseURL;         /* Full text of the URL being served */
  char *zTop;             /* Parent directory of zPath */
  const char *zContentType;  /* The content type of the input HTTP request */
  int iErrPriority;       /* Priority of current error message */
  char *zErrMsg;          /* Text of an error message */
  int sslNotAvailable;    /* SSL is not available.  Do not redirect to https: */
  Blob cgiIn;             /* Input to an xfer www method */
  int cgiOutput;          /* Write error and status messages to CGI */
  int xferPanic;          /* Write error messages in XFER protocol */
  int fullHttpReply;      /* True for full HTTP reply.  False for CGI reply */
  Th_Interp *interp;      /* The TH1 interpreter */
  FILE *httpIn;           /* Accept HTTP input from here */
  FILE *httpOut;          /* Send HTTP output here */
  int xlinkClusterOnly;   /* Set when cloning.  Only process clusters */
  int fTimeFormat;        /* 1 for UTC.  2 for localtime.  0 not yet selected */
  int *aCommitFile;       /* Array of files to be committed */
  int markPrivate;        /* All new artifacts are private if true */
  int clockSkewSeen;      /* True if clocks on client and server out of sync */

  int urlIsFile;          /* True if a "file:" url */
  int urlIsHttps;         /* True if a "https:" url */
  int urlIsSsh;           /* True if an "ssh:" url */
  char *urlName;          /* Hostname for http: or filename for file: */
  char *urlHostname;      /* The HOST: parameter on http headers */
  char *urlProtocol;      /* "http" or "https" */
  int urlPort;            /* TCP port number for http: or https: */
  int urlDfltPort;        /* The default port for the given protocol */
  char *urlPath;          /* Pathname for http: */
  char *urlUser;          /* User id for http: */
  char *urlPasswd;        /* Password for http: */
  char *urlCanonical;     /* Canonical representation of the URL */
  char *urlProxyAuth;     /* Proxy-Authorizer: string */
  char *urlFossil;        /* The path of the ?fossil=path suffix on ssh: */
  int dontKeepUrl;        /* Do not persist the URL */

  const char *zLogin;     /* Login name.  "" if not logged in. */
  int useLocalauth;       /* No login required if from 127.0.0.1 */
  int noPswd;             /* Logged in without password (on 127.0.0.1) */
  int userUid;            /* Integer user id */

  /* Information used to populate the RCVFROM table */
  int rcvid;              /* The rcvid.  0 if not yet defined. */
  char *zIpAddr;          /* The remote IP address */
  char *zNonce;           /* The nonce used for login */
  
  /* permissions used by the server */
  int okSetup;            /* s: use Setup screens on web interface */
  int okAdmin;            /* a: administrative permission */
  int okDelete;           /* d: delete wiki or tickets */
  int okPassword;         /* p: change password */
  int okQuery;            /* q: create new reports */
  int okWrite;            /* i: xfer inbound. checkin */
  int okRead;             /* o: xfer outbound. checkout */
  int okHistory;          /* h: access historical information. */
  int okClone;            /* g: clone */
  int okRdWiki;           /* j: view wiki via web */
  int okNewWiki;          /* f: create new wiki via web */
  int okApndWiki;         /* m: append to wiki via web */
  int okWrWiki;           /* k: edit wiki via web */
  int okRdTkt;            /* r: view tickets via web */
  int okNewTkt;           /* n: create new tickets */
  int okApndTkt;          /* c: append to tickets via the web */
  int okWrTkt;            /* w: make changes to tickets via web */
  int okAttach;           /* b: add attachments */
  int okTktFmt;           /* t: create new ticket report formats */
  int okRdAddr;           /* e: read email addresses or other private data */
  int okZip;              /* z: download zipped artifact via /zip URL */
  int okPrivate;          /* x: can send and receive private content */

  /* For defense against Cross-site Request Forgery attacks */
  char zCsrfToken[12];    /* Value of the anti-CSRF token */
  int okCsrf;             /* Anti-CSRF token is present and valid */

  FILE *fDebug;           /* Write debug information here, if the file exists */
  int thTrace;            /* True to enable TH1 debugging output */
  Blob thLog;             /* Text of the TH1 debugging output */

  int isHome;             /* True if rendering the "home" page */

  /* Storage for the aux() and/or option() SQL function arguments */
  int nAux;                    /* Number of distinct aux() or option() values */
  const char *azAuxName[MX_AUX]; /* Name of each aux() or option() value */
  char *azAuxParam[MX_AUX];      /* Param of each aux() or option() value */
  const char *azAuxVal[MX_AUX];  /* Value of each aux() or option() value */
  const char **azAuxOpt[MX_AUX]; /* Options of each option() value */
  int anAuxCols[MX_AUX];         /* Number of columns for option() values */
};
extern Global g;
void login_check_credentials(void);
struct Stmt {
  Blob sql;               /* The SQL for this statement */
  sqlite3_stmt *pStmt;    /* The results of sqlite3_prepare() */
  Stmt *pNext, *pPrev;    /* List of all unfinalized statements */
  int nStep;              /* Number of sqlite3_step() calls */
};
void view_list(void);
